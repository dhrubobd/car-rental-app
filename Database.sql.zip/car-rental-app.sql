-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 27, 2024 at 04:01 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `car-rental-app`
--

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(30) NOT NULL,
  `brand` varchar(30) NOT NULL,
  `model` varchar(30) NOT NULL,
  `year` int(11) NOT NULL,
  `car_type` varchar(30) NOT NULL,
  `daily_rent_price` decimal(6,2) NOT NULL,
  `availability` tinyint(1) NOT NULL,
  `image` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`id`, `name`, `brand`, `model`, `year`, `car_type`, `daily_rent_price`, `availability`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Axio', 'Toyota', 'My Model', 2019, 'Sedan', 100.00, 1, 'uploads/car1.jpg', '2024-09-19 03:54:26', '2024-09-25 15:17:19'),
(2, 'BMW iX', 'BMW', 'MY25-iX', 2021, 'SUV Electric', 200.50, 1, 'uploads/car2.jpg', '2024-09-19 03:54:26', '2024-09-26 15:17:10'),
(3, 'CH-R', 'Toyota', '2018', 2022, 'SUV', 150.99, 1, 'uploads/car3.jpg', '2024-09-19 03:54:26', '2024-09-25 12:23:35'),
(4, 'Almera', 'Nissan', '2022', 2023, 'Sedan', 120.98, 1, 'uploads/car4.jpg', '2024-09-19 03:54:26', '2024-09-25 15:19:06'),
(5, 'Model Y', 'Tesla', '2023', 2023, 'Sedan Electric', 180.50, 1, 'uploads/car5.jpg', '2024-09-19 03:54:26', '2024-09-25 15:18:46');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2024_09_16_151912_create_users_table', 1),
(7, '2024_09_16_151934_create_cars_table', 1),
(8, '2024_09_16_151954_create_rentals_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rentals`
--

CREATE TABLE `rentals` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `car_id` bigint(20) UNSIGNED NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `total_cost` decimal(8,2) NOT NULL,
  `status` enum('ongoing','completed','cancelled') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rentals`
--

INSERT INTO `rentals` (`id`, `user_id`, `car_id`, `start_date`, `end_date`, `total_cost`, `status`, `created_at`, `updated_at`) VALUES
(6, 6, 4, '2024-09-27', '2024-09-28', 120.00, 'completed', '2024-09-22 03:13:08', '2024-09-23 20:35:41'),
(7, 6, 3, '2024-09-25', '2024-09-30', 750.00, 'ongoing', '2024-09-23 09:52:19', '2024-09-23 09:52:19'),
(8, 6, 5, '2024-09-24', '2024-09-30', 1080.00, 'ongoing', '2024-09-23 09:54:33', '2024-09-23 09:54:33'),
(10, 6, 5, '2024-10-09', '2024-10-15', 1260.00, 'completed', '2024-09-23 10:03:55', '2024-09-23 20:35:29'),
(11, 6, 3, '2024-10-23', '2024-10-23', 150.00, 'ongoing', '2024-09-23 11:14:33', '2024-09-23 11:14:33'),
(12, 2, 2, '2024-09-26', '2024-09-26', 200.00, 'cancelled', '2024-09-24 14:05:03', '2024-09-24 14:05:45'),
(13, 2, 3, '2024-09-26', '2024-09-28', 450.00, 'ongoing', '2024-09-24 14:09:54', '2024-09-26 11:50:30'),
(14, 14, 4, '2024-10-08', '2024-10-10', 360.00, 'cancelled', '2024-09-24 14:15:52', '2024-09-24 21:51:42'),
(15, 14, 1, '2024-09-25', '2024-09-25', 100.00, 'completed', '2024-09-24 21:51:20', '2024-09-26 11:39:48'),
(16, 4, 1, '2024-09-27', '2024-09-28', 200.00, 'completed', '2024-09-26 08:02:05', '2024-09-26 08:02:05'),
(17, 3, 5, '2024-10-29', '2024-10-30', 361.00, 'completed', '2024-09-26 08:06:35', '2024-09-26 08:06:35'),
(18, 5, 5, '2024-09-29', '2024-09-29', 180.50, 'completed', '2024-09-26 08:27:57', '2024-09-26 11:56:18'),
(19, 4, 4, '2024-10-08', '2024-10-10', 362.94, 'completed', '2024-09-26 08:42:36', '2024-09-26 12:01:25'),
(21, 6, 5, '2024-10-02', '2024-10-04', 541.50, 'ongoing', '2024-09-26 14:12:08', '2024-09-26 14:12:08'),
(22, 6, 3, '2024-10-13', '2024-10-13', 150.99, 'ongoing', '2024-09-26 14:19:50', '2024-09-26 14:19:50'),
(23, 6, 1, '2024-11-14', '2024-11-15', 200.00, 'ongoing', '2024-09-26 14:28:58', '2024-09-26 14:28:58'),
(27, 4, 2, '2024-12-24', '2024-12-31', 1604.00, 'completed', '2024-09-26 15:48:56', '2024-09-26 15:48:56'),
(28, 19, 3, '2024-12-06', '2024-12-07', 301.98, 'cancelled', '2024-09-26 15:54:54', '2024-09-26 15:55:23');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(7) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `address` varchar(200) NOT NULL,
  `role` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `phone`, `address`, `role`, `created_at`, `updated_at`) VALUES
(1, 'Harry Potter', 'admin@admin.com', 'admin', '8073137955', 'Ducimus rerum sunt nihil repellat ducimus et officiis.', 'admin', '2024-09-17 19:24:45', '2024-09-25 03:19:56'),
(2, 'Hasnat Abdullah', 'RfkfQBecZD@example.com', 'l1gNOQX', '6211287694', 'Aperiam et reiciendis sit provident odit hic enim rerum ut accusamus autem est doloremque.', 'customer', '2024-09-17 19:24:45', '2024-09-17 19:24:45'),
(3, 'Dipty Chowdhruy', 'JJ6vbz1Kgh@example.com', 'a93OIpi', '3307248192', 'Distinctio aut reprehenderit autem iste et et magnam et consequatur ullam.', 'customer', '2024-09-17 19:24:45', '2024-09-17 19:24:45'),
(4, 'Sarjis Alom', 'gBELJvRxT1@example.com', 'pass', '6275638793', 'Quam architecto ducimus esse consequuntur quae perferendis corporis minus consequatur.', 'customer', '2024-09-17 19:24:45', '2024-09-26 15:45:48'),
(5, 'Sadia Sraboni', 'HifvKdVFIx@example.com', 'AmwFyHY', '8675986002', 'Est eum repellendus non ea qui ex et molestiae nihil rem cupiditate quas.', 'customer', '2024-09-17 19:24:45', '2024-09-17 19:24:45'),
(6, 'Luke Test', 'test@gmail.com', 'pass', '01786494504', 'Bethel House, 141 Sreenath Chatterjee Lane, Bogura Road, Barishal', 'customer', '2024-09-17 22:15:45', '2024-09-26 20:52:24'),
(7, 'Harry Potter', 'ipfkVWbNHa@example.com', 'r9LkcpO', '2411234488', 'Ut perferendis impedit ex ipsum ipsum numquam eos modi sed dicta earum.', 'admin', '2024-09-19 03:54:26', '2024-09-19 03:54:26'),
(14, 'Mosaddek Nobel', 'dsa@afa.com', 'pass', '243442324', 'Sadar Road, Barishal', 'customer', '2024-09-24 14:13:31', '2024-09-24 14:13:31'),
(18, 'New Customer', 'aff2@ds.com', 'pass', '224345452', 'Tes Address', 'customer', '2024-09-26 15:45:24', '2024-09-26 15:45:24'),
(19, 'Luke Kalyan Brata Sarker', 'dhrubo.luke@gmail.com', 'pass', '01786494504', 'Bethel House, 141 Sreenath Chatterjee Lane, Bogura Road, Barishal', 'customer', '2024-09-26 15:54:01', '2024-09-26 15:54:01'),
(20, 'New Customer 2', 'test@2dsfsa.com', 'pass', '2353243332', 'Tes Address', 'customer', '2024-09-26 15:56:54', '2024-09-26 15:57:14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `rentals`
--
ALTER TABLE `rentals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rentals_user_id_foreign` (`user_id`),
  ADD KEY `rentals_car_id_foreign` (`car_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rentals`
--
ALTER TABLE `rentals`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `rentals`
--
ALTER TABLE `rentals`
  ADD CONSTRAINT `rentals_car_id_foreign` FOREIGN KEY (`car_id`) REFERENCES `cars` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `rentals_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
